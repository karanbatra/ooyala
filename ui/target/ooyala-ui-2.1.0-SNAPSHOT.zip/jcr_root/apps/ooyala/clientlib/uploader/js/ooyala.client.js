/**
 * Bootstrap the Ooyala.Client namespace.
 * */

if(!window.Ooyala){
  window.Ooyala = {};
}

Ooyala.Client = {} || Ooyala.Client;

